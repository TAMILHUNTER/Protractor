import { browser, by, element, ElementFinder } from "protractor";

export class angularjsPageObjects {

}
