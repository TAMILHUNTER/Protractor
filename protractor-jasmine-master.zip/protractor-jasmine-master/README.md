
# Protractor Jasmine Test Framework

Command to set test env : export env= qa | dev | 

Command to start webdriver server webdriver-manager start 

Command to run test using protractor command protractor protractor.conf.conf 

Command to run test from gulp file : gulp test 

Command to run test based on tag protractor protractor.conf.js --grep='@regression|@smoke'

