module.exports={
    local:{
        baseUrl: 'https://angular.io/resources'
    },
    dev:{
        baseUrl:'https://angular.io/'
    },
    qa:{
        baseUrl:'https://angular.io/'
    }
}



