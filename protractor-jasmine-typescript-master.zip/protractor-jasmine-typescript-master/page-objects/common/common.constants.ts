export class commonPageConstants {

    static get pageContent() {
        return {
            pageTitle: 'Super Calculator'
        };
    }

}
